import pygame
import sys
pygame.font.init()
from collections import deque
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 30, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 20, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 17)
SMALL_FONT = pygame.font.SysFont("arial", 14)


class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def bst_insert(root, value):
    if root is None:
        return BSTNode(value)

    if value < root.value:
        root.left = bst_insert(root.left, value)
    elif value > root.value:
        root.right = bst_insert(root.right, value)

    return root


def inorder_traversal(root, result):
    if root is not None:
        inorder_traversal(root.left, result)
        result.append(root.value)
        inorder_traversal(root.right, result)


def draw_stack(screen, stack):
    draw_text(screen, "Stack", SUBTITLE_FONT, DARK, 140, 105, True)
    draw_text(screen, "LIFO", SMALL_FONT, GREY, 140, 128, True)

    base_x = 95
    base_y = 315
    width = 90
    height = 30

    pygame.draw.line(screen, DARK, (base_x - 8, base_y + 8), (base_x + width + 8, base_y + 8), 3)

    for i, value in enumerate(stack):
        rect = pygame.Rect(base_x, base_y - (i + 1) * height, width, height - 4)
        color = YELLOW if i == len(stack) - 1 else LIGHT_BLUE
        pygame.draw.rect(screen, color, rect, border_radius=7)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=7)
        draw_text(screen, str(value), SMALL_FONT, DARK, rect.centerx, rect.centery, True)

    if len(stack) == 0:
        draw_text(screen, "Empty", NORMAL_FONT, GREY, 140, 220, True)


def draw_queue(screen, queue_items):
    draw_text(screen, "Queue", SUBTITLE_FONT, DARK, 380, 105, True)
    draw_text(screen, "FIFO", SMALL_FONT, GREY, 380, 128, True)

    start_x = 245
    y = 215
    width = 48
    height = 38

    for i, value in enumerate(queue_items):
        rect = pygame.Rect(start_x + i * 55, y, width, height)
        color = YELLOW if i == 0 else LIGHT_GREEN
        pygame.draw.rect(screen, color, rect, border_radius=7)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=7)
        draw_text(screen, str(value), SMALL_FONT, DARK, rect.centerx, rect.centery, True)

    if len(queue_items) == 0:
        draw_text(screen, "Empty", NORMAL_FONT, GREY, 380, 230, True)


def draw_linked_list(screen, linked_list):
    draw_text(screen, "Linked List", SUBTITLE_FONT, DARK, 700, 105, True)
    draw_text(screen, "Insert, Delete, Reverse", SMALL_FONT, GREY, 700, 128, True)

    start_x = 540
    y = 215
    node_w = 52
    node_h = 38
    gap = 25

    if len(linked_list) == 0:
        draw_text(screen, "Empty", NORMAL_FONT, GREY, 700, 230, True)
        return

    for i, value in enumerate(linked_list):
        x = start_x + i * (node_w + gap)
        rect = pygame.Rect(x, y, node_w, node_h)
        color = ORANGE if i == 0 else LIGHT_PURPLE
        pygame.draw.rect(screen, color, rect, border_radius=7)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=7)
        draw_text(screen, str(value), SMALL_FONT, DARK, rect.centerx, rect.centery, True)

        if i < len(linked_list) - 1:
            arrow_start = (x + node_w + 3, y + node_h // 2)
            arrow_end = (x + node_w + gap - 5, y + node_h // 2)
            pygame.draw.line(screen, DARK, arrow_start, arrow_end, 2)
            pygame.draw.polygon(screen, DARK, [
                (arrow_end[0], arrow_end[1]),
                (arrow_end[0] - 8, arrow_end[1] - 5),
                (arrow_end[0] - 8, arrow_end[1] + 5)
            ])


def draw_bst_node(screen, node, x, y, x_gap):
    if node is None:
        return

    radius = 22

    if node.left is not None:
        child_x = x - x_gap
        child_y = y + 75
        pygame.draw.line(screen, DARK, (x, y + radius), (child_x, child_y - radius), 2)
        draw_bst_node(screen, node.left, child_x, child_y, max(35, x_gap // 2))

    if node.right is not None:
        child_x = x + x_gap
        child_y = y + 75
        pygame.draw.line(screen, DARK, (x, y + radius), (child_x, child_y - radius), 2)
        draw_bst_node(screen, node.right, child_x, child_y, max(35, x_gap // 2))

    pygame.draw.circle(screen, LIGHT_BLUE, (x, y), radius)
    pygame.draw.circle(screen, DARK, (x, y), radius, 2)
    draw_text(screen, str(node.value), SMALL_FONT, DARK, x, y, True)


def draw_bst(screen, root, traversal_result):
    draw_text(screen, "Binary Search Tree", SUBTITLE_FONT, DARK, 500, 350, True)
    draw_text(screen, "Insert values and show Inorder Traversal", SMALL_FONT, GREY, 500, 373, True)

    if root is None:
        draw_text(screen, "Tree is empty", NORMAL_FONT, GREY, 500, 475, True)
    else:
        draw_bst_node(screen, root, 500, 430, 170)

    if traversal_result:
        text = "Inorder: " + " → ".join(str(x) for x in traversal_result)
        draw_text(screen, text, NORMAL_FONT, DARK, 500, 650, True)


def run_data_structures_module(screen, clock):
    stack = []
    queue_items = deque()
    linked_list = []
    bst_root = None
    bst_values = [50, 30, 70, 20, 40, 60, 80]
    bst_index = 0
    traversal_result = []
    next_value = 1
    message = "Choose an operation."

    buttons = {
        "push": Button("Push", 40, 565, 90, 38, LIGHT_BLUE, BLUE),
        "pop": Button("Pop", 140, 565, 90, 38, LIGHT_RED, RED),
        "enqueue": Button("Enqueue", 240, 565, 105, 38, LIGHT_GREEN, GREEN),
        "dequeue": Button("Dequeue", 355, 565, 105, 38, LIGHT_RED, RED),
        "insert": Button("Insert Node", 470, 565, 115, 38, LIGHT_PURPLE, PURPLE),
        "delete": Button("Delete Node", 595, 565, 115, 38, LIGHT_RED, RED),
        "reverse": Button("Reverse", 720, 565, 100, 38, LIGHT_BLUE, BLUE),
        "bst_insert": Button("BST Insert", 830, 565, 120, 38, LIGHT_GREEN, GREEN),
        "bst_traversal": Button("BST Inorder", 390, 610, 140, 38, LIGHT_BLUE, BLUE),
        "back": Button("Back", 850, 30, 100, 38, LIGHT_PURPLE, PURPLE)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Data Structures Module", TITLE_FONT, DARK, 500, 42, True)
        draw_text(screen, "Stack, Queue, Linked List, and Binary Search Tree", NORMAL_FONT, GREY, 500, 72, True)

        pygame.draw.line(screen, GREY, (215, 95), (215, 330), 2)
        pygame.draw.line(screen, GREY, (515, 95), (515, 330), 2)
        pygame.draw.line(screen, GREY, (60, 335), (940, 335), 2)

        draw_stack(screen, stack)
        draw_queue(screen, list(queue_items))
        draw_linked_list(screen, linked_list)
        draw_bst(screen, bst_root, traversal_result)

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, 500, 680, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if buttons["push"].is_clicked(event):
                if len(stack) < 6:
                    stack.append(next_value)
                    message = f"Stack push: {next_value}"
                    next_value += 1
                else:
                    message = "Stack is full."

            elif buttons["pop"].is_clicked(event):
                if stack:
                    removed = stack.pop()
                    message = f"Stack pop: {removed}"
                else:
                    message = "Stack is empty."

            elif buttons["enqueue"].is_clicked(event):
                if len(queue_items) < 5:
                    queue_items.append(next_value)
                    message = f"Queue enqueue: {next_value}"
                    next_value += 1
                else:
                    message = "Queue is full."

            elif buttons["dequeue"].is_clicked(event):
                if queue_items:
                    removed = queue_items.popleft()
                    message = f"Queue dequeue: {removed}"
                else:
                    message = "Queue is empty."

            elif buttons["insert"].is_clicked(event):
                if len(linked_list) < 6:
                    linked_list.append(next_value)
                    message = f"Linked list insert: {next_value}"
                    next_value += 1
                else:
                    message = "Linked list is full."

            elif buttons["delete"].is_clicked(event):
                if linked_list:
                    removed = linked_list.pop()
                    message = f"Linked list delete: {removed}"
                else:
                    message = "Linked list is empty."

            elif buttons["reverse"].is_clicked(event):
                if linked_list:
                    linked_list.reverse()
                    message = "Linked list reversed."
                else:
                    message = "Linked list is empty."

            elif buttons["bst_insert"].is_clicked(event):
                if bst_index < len(bst_values):
                    value = bst_values[bst_index]
                    bst_root = bst_insert(bst_root, value)
                    bst_index += 1
                    traversal_result = []
                    message = f"BST insert: {value}"
                else:
                    message = "All BST values inserted."

            elif buttons["bst_traversal"].is_clicked(event):
                traversal_result = []
                inorder_traversal(bst_root, traversal_result)
                if traversal_result:
                    message = "BST inorder traversal displayed."
                else:
                    message = "Tree is empty."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)