import pygame
import sys
pygame.font.init()
from collections import deque
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 32, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 22, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 17)
SMALL_FONT = pygame.font.SysFont("arial", 14)


class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def bst_insert(root, value):
    if root is None:
        return BSTNode(value)

    if value < root.value:
        root.left = bst_insert(root.left, value)  # smaller value goes left
    elif value > root.value:
        root.right = bst_insert(root.right, value)  # bigger value goes right

    return root


def inorder_traversal(root, result):
    if root is not None:
        inorder_traversal(root.left, result)
        result.append(root.value)  # visit root
        inorder_traversal(root.right, result)


def draw_stack(screen, stack, offset_x):
    cx = offset_x + 140
    draw_text(screen, "Stack", SUBTITLE_FONT, DARK, cx, 115, True)
    draw_text(screen, "LIFO", SMALL_FONT, GREY, cx, 140, True)

    base_x = offset_x + 95
    base_y = 330
    width = 90
    height = 30

    pygame.draw.line(screen, DARK, (base_x - 8, base_y + 8), (base_x + width + 8, base_y + 8), 3)

    for i, value in enumerate(stack):
        rect = pygame.Rect(base_x, base_y - (i + 1) * height, width, height - 4)
        color = YELLOW if i == len(stack) - 1 else LIGHT_BLUE
        pygame.draw.rect(screen, color, rect, border_radius=7)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=7)
        draw_text(screen, str(value), SMALL_FONT, DARK, rect.centerx, rect.centery, True)

    if not stack:
        draw_text(screen, "Empty", NORMAL_FONT, GREY, cx, 235, True)


def draw_queue(screen, queue_items, offset_x):
    cx = offset_x + 380
    draw_text(screen, "Queue", SUBTITLE_FONT, DARK, cx, 115, True)
    draw_text(screen, "FIFO", SMALL_FONT, GREY, cx, 140, True)

    start_x = offset_x + 245
    y = 225
    width = 48
    height = 38

    for i, value in enumerate(queue_items):
        rect = pygame.Rect(start_x + i * 55, y, width, height)
        color = YELLOW if i == 0 else LIGHT_GREEN
        pygame.draw.rect(screen, color, rect, border_radius=7)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=7)
        draw_text(screen, str(value), SMALL_FONT, DARK, rect.centerx, rect.centery, True)

    if not queue_items:
        draw_text(screen, "Empty", NORMAL_FONT, GREY, cx, 240, True)


def draw_linked_list(screen, linked_list, offset_x):
    cx = offset_x + 760
    draw_text(screen, "Linked List", SUBTITLE_FONT, DARK, cx, 115, True)
    draw_text(screen, "Insert, Delete, Reverse", SMALL_FONT, GREY, cx, 140, True)

    start_x = offset_x + 580
    y = 225
    node_w = 52
    node_h = 38
    gap = 25

    if not linked_list:
        draw_text(screen, "Empty", NORMAL_FONT, GREY, cx, 240, True)
        return

    for i, value in enumerate(linked_list):
        x = start_x + i * (node_w + gap)
        rect = pygame.Rect(x, y, node_w, node_h)
        color = ORANGE if i == 0 else LIGHT_PURPLE
        pygame.draw.rect(screen, color, rect, border_radius=7)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=7)
        draw_text(screen, str(value), SMALL_FONT, DARK, rect.centerx, rect.centery, True)

        if i < len(linked_list) - 1:
            arrow_start = (x + node_w + 3, y + node_h // 2)
            arrow_end = (x + node_w + gap - 5, y + node_h // 2)
            pygame.draw.line(screen, DARK, arrow_start, arrow_end, 2)
            pygame.draw.polygon(screen, DARK, [
                (arrow_end[0], arrow_end[1]),
                (arrow_end[0] - 8, arrow_end[1] - 5),
                (arrow_end[0] - 8, arrow_end[1] + 5)
            ])


def draw_bst_node(screen, node, x, y, x_gap):
    if node is None:
        return

    radius = 22

    if node.left is not None:
        child_x = x - x_gap
        child_y = y + 78
        pygame.draw.line(screen, DARK, (x, y + radius), (child_x, child_y - radius), 2)
        draw_bst_node(screen, node.left, child_x, child_y, max(40, x_gap // 2))

    if node.right is not None:
        child_x = x + x_gap
        child_y = y + 78
        pygame.draw.line(screen, DARK, (x, y + radius), (child_x, child_y - radius), 2)
        draw_bst_node(screen, node.right, child_x, child_y, max(40, x_gap // 2))

    pygame.draw.circle(screen, LIGHT_BLUE, (x, y), radius)
    pygame.draw.circle(screen, DARK, (x, y), radius, 2)
    draw_text(screen, str(node.value), SMALL_FONT, DARK, x, y, True)


def draw_bst(screen, root, traversal_result, center_x):
    draw_text(screen, "Binary Search Tree", SUBTITLE_FONT, DARK, center_x, 385, True)
    draw_text(screen, "Insert values and display inorder traversal", SMALL_FONT, GREY, center_x, 410, True)

    if root is None:
        draw_text(screen, "Tree is empty", NORMAL_FONT, GREY, center_x, 510, True)
    else:
        draw_bst_node(screen, root, center_x, 465, 190)

    if traversal_result:
        text = "Inorder Traversal: " + " → ".join(str(x) for x in traversal_result)
        text_surface = NORMAL_FONT.render(text, True, DARK)
        text_rect = text_surface.get_rect(center=(center_x, 710))
        screen.blit(text_surface, text_rect)


def run_data_structures_module(screen, clock):
    width = screen.get_width()
    height = screen.get_height()
    center_x = width // 2
    offset_x = (width - 1000) // 2  # center layout

    stack = []  # stack values
    queue_items = deque()  # queue values
    linked_list = []  # linked list values
    bst_root = None  # tree root
    bst_values = [50, 30, 70, 20, 40, 60, 80]
    bst_index = 0
    traversal_result = []
    next_value = 1
    message = "Select an operation below."

    buttons = {
        "push": Button("Push", offset_x + 35, 595, 95, 42, LIGHT_BLUE, BLUE),
        "pop": Button("Pop", offset_x + 140, 595, 95, 42, LIGHT_RED, RED),
        "enqueue": Button("Enqueue", offset_x + 250, 595, 115, 42, LIGHT_GREEN, GREEN),
        "dequeue": Button("Dequeue", offset_x + 380, 595, 115, 42, LIGHT_RED, RED),
        "insert": Button("Insert Node", offset_x + 510, 595, 130, 42, LIGHT_PURPLE, PURPLE),
        "delete": Button("Delete Node", offset_x + 655, 595, 130, 42, LIGHT_RED, RED),
        "reverse": Button("Reverse", offset_x + 800, 595, 110, 42, LIGHT_BLUE, BLUE),
        "bst_insert": Button("BST Insert", offset_x + 925, 595, 130, 42, LIGHT_GREEN, GREEN),
        "bst_traversal": Button("BST Inorder", center_x - 75, 645, 150, 42, LIGHT_BLUE, BLUE),
        "back": Button("Back", width - 150, 35, 105, 42, LIGHT_PURPLE, PURPLE)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Data Structures Module", TITLE_FONT, DARK, center_x, 45, True)
        draw_text(screen, "Stack, Queue, Linked List, and Binary Search Tree", NORMAL_FONT, GREY, center_x, 78, True)

        pygame.draw.line(screen, GREY, (offset_x + 215, 105), (offset_x + 215, 360), 2)
        pygame.draw.line(screen, GREY, (offset_x + 535, 105), (offset_x + 535, 360), 2)
        pygame.draw.line(screen, GREY, (offset_x + 60, 365), (offset_x + 1060, 365), 2)

        draw_stack(screen, stack, offset_x)
        draw_queue(screen, list(queue_items), offset_x)
        draw_linked_list(screen, linked_list, offset_x)
        draw_bst(screen, bst_root, traversal_result, center_x)

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, center_x, 755, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if buttons["push"].is_clicked(event):
                if len(stack) < 6:
                    stack.append(next_value)  # push value
                    message = f"Stack push: {next_value}"
                    next_value += 1
                else:
                    message = "Stack is full."

            elif buttons["pop"].is_clicked(event):
                if stack:
                    removed = stack.pop()  # pop value
                    message = f"Stack pop: {removed}"
                else:
                    message = "Stack is empty."

            elif buttons["enqueue"].is_clicked(event):
                if len(queue_items) < 5:
                    queue_items.append(next_value)  # add to queue
                    message = f"Queue enqueue: {next_value}"
                    next_value += 1
                else:
                    message = "Queue is full."

            elif buttons["dequeue"].is_clicked(event):
                if queue_items:
                    removed = queue_items.popleft()  # remove from front
                    message = f"Queue dequeue: {removed}"
                else:
                    message = "Queue is empty."

            elif buttons["insert"].is_clicked(event):
                if len(linked_list) < 6:
                    linked_list.append(next_value)  # add node
                    message = f"Linked list insert: {next_value}"
                    next_value += 1
                else:
                    message = "Linked list is full."

            elif buttons["delete"].is_clicked(event):
                if linked_list:
                    removed = linked_list.pop()  # delete node
                    message = f"Linked list delete: {removed}"
                else:
                    message = "Linked list is empty."

            elif buttons["reverse"].is_clicked(event):
                if linked_list:
                    linked_list.reverse()  # reverse list
                    message = "Linked list reversed."
                else:
                    message = "Linked list is empty."

            elif buttons["bst_insert"].is_clicked(event):
                if bst_index < len(bst_values):
                    value = bst_values[bst_index]
                    bst_root = bst_insert(bst_root, value)  # insert into BST
                    bst_index += 1
                    traversal_result = []
                    message = f"BST insert: {value}"
                else:
                    message = "All BST values inserted."

            elif buttons["bst_traversal"].is_clicked(event):
                traversal_result = []
                inorder_traversal(bst_root, traversal_result)  # sorted order
                if traversal_result:
                    message = "BST inorder traversal displayed."
                else:
                    message = "Tree is empty."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)