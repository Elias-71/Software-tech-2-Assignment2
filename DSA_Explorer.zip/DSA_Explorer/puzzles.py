import pygame
import sys
import heapq
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 32, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 18)
SMALL_FONT = pygame.font.SysFont("arial", 14)


def dijkstra_path(rows, cols, start, end, obstacles, weights):
    priority_queue = [(0, start)]
    distances = {start: 0}
    parent = {}
    visit_order = []

    while priority_queue:
        current_distance, current = heapq.heappop(priority_queue)

        if current in visit_order:
            continue

        visit_order.append(current)

        if current == end:
            break

        row, col = current
        neighbours = [
            (row - 1, col),
            (row + 1, col),
            (row, col - 1),
            (row, col + 1)
        ]

        for next_cell in neighbours:
            r, c = next_cell

            if 0 <= r < rows and 0 <= c < cols:
                if next_cell not in obstacles:
                    new_distance = current_distance + weights[next_cell]

                    if new_distance < distances.get(next_cell, float("inf")):
                        distances[next_cell] = new_distance
                        parent[next_cell] = current
                        heapq.heappush(priority_queue, (new_distance, next_cell))

    path = []

    if end in parent or start == end:
        current = end

        while current != start:
            path.append(current)
            current = parent[current]

        path.append(start)
        path.reverse()

    return visit_order, path, distances.get(end, None)


def draw_grid(screen, rows, cols, cell_size, start_x, start_y, start, end, obstacles, visited, path, weights):
    for row in range(rows):
        for col in range(cols):
            cell = (row, col)
            x = start_x + col * cell_size
            y = start_y + row * cell_size
            rect = pygame.Rect(x, y, cell_size, cell_size)

            color = WHITE

            if cell in visited:
                color = LIGHT_BLUE

            if cell in path:
                color = YELLOW

            if cell in obstacles:
                color = DARK

            if cell == start:
                color = GREEN

            if cell == end:
                color = RED

            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, GREY, rect, 1)

            if cell not in obstacles and cell != start and cell != end:
                draw_text(screen, str(weights[cell]), SMALL_FONT, DARK, x + cell_size // 2, y + cell_size // 2, True)


def get_clicked_cell(mouse_pos, rows, cols, cell_size, start_x, start_y):
    mx, my = mouse_pos

    if mx < start_x or my < start_y:
        return None

    col = (mx - start_x) // cell_size
    row = (my - start_y) // cell_size

    if 0 <= row < rows and 0 <= col < cols:
        return (row, col)

    return None


def run_puzzle_challenges(screen, clock):
    rows = 10
    cols = 15
    cell_size = 42
    start_x = 185
    start_y = 125

    start = (2, 1)
    end = (7, 13)

    weights = {}

    for row in range(rows):
        for col in range(cols):
            weights[(row, col)] = ((row + col) % 4) + 1

    obstacles = {
        (1, 5), (2, 5), (3, 5), (4, 5),
        (6, 3), (6, 4), (6, 5), (6, 6),
        (3, 9), (4, 9), (5, 9), (6, 9),
        (8, 10), (8, 11), (8, 12)
    }

    original_obstacles = set(obstacles)

    visited_order = []
    visited_display = []
    path = []
    path_cost = None
    step_index = 0
    running_path = False
    frame_counter = 0
    speed = 5
    message = "Click cells to add or remove obstacles."

    buttons = {
        "run": Button("Run Dijkstra", 180, 570, 150, 42, LIGHT_BLUE, BLUE),
        "clear": Button("Clear Path", 350, 570, 130, 42, LIGHT_PURPLE, PURPLE),
        "reset": Button("Reset Map", 500, 570, 130, 42, LIGHT_GREEN, GREEN),
        "back": Button("Back", 650, 570, 130, 42, LIGHT_RED, RED)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Puzzle Challenges", TITLE_FONT, DARK, 500, 45, True)
        draw_text(screen, "Weighted shortest path puzzle using Dijkstra's Algorithm.", NORMAL_FONT, GREY, 500, 78, True)

        draw_grid(
            screen,
            rows,
            cols,
            cell_size,
            start_x,
            start_y,
            start,
            end,
            obstacles,
            set(visited_display),
            set(path),
            weights
        )

        if running_path:
            frame_counter += 1

            if frame_counter >= speed:
                frame_counter = 0

                if step_index < len(visited_order):
                    visited_display.append(visited_order[step_index])
                    step_index += 1
                    message = "Dijkstra is searching for the lowest-cost path."
                else:
                    running_path = False
                    if path:
                        message = f"Lowest-cost path found. Cost: {path_cost}"
                    else:
                        message = "No path found."

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, 500, 645, True)
        draw_text(screen, "Numbers = movement cost, green = start, red = end, dark = obstacle, yellow = final path", SMALL_FONT, GREY, 500, 675, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                clicked_cell = get_clicked_cell(event.pos, rows, cols, cell_size, start_x, start_y)

                if clicked_cell is not None and not running_path:
                    if clicked_cell != start and clicked_cell != end:
                        if clicked_cell in obstacles:
                            obstacles.remove(clicked_cell)
                            message = "Obstacle removed."
                        else:
                            obstacles.add(clicked_cell)
                            message = "Obstacle added."

                        visited_order = []
                        visited_display = []
                        path = []
                        path_cost = None
                        step_index = 0

            if buttons["run"].is_clicked(event):
                visited_order, path, path_cost = dijkstra_path(rows, cols, start, end, obstacles, weights)
                visited_display = []
                step_index = 0
                running_path = True
                message = "Dijkstra started."

            elif buttons["clear"].is_clicked(event):
                visited_order = []
                visited_display = []
                path = []
                path_cost = None
                step_index = 0
                running_path = False
                message = "Path cleared."

            elif buttons["reset"].is_clicked(event):
                obstacles = set(original_obstacles)
                visited_order = []
                visited_display = []
                path = []
                path_cost = None
                step_index = 0
                running_path = False
                message = "Map reset."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)