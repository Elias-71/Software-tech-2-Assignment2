import pygame
import sys
import heapq
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)

TITLE_FONT = pygame.font.SysFont("arial", 34, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 18)
SMALL_FONT = pygame.font.SysFont("arial", 14)


def dijkstra_path(rows, cols, start, end, obstacles, weights):
    priority_queue = [(0, start)]  # lowest cost cell first
    distances = {start: 0}  # best cost to each cell
    parent = {}  # rebuild final path
    visit_order = []  # visited cells order

    while priority_queue:
        current_distance, current = heapq.heappop(priority_queue)  # get cheapest cell

        if current in visit_order:
            continue

        visit_order.append(current)

        if current == end:
            break

        row, col = current
        neighbours = [
            (row - 1, col),  # up
            (row + 1, col),  # down
            (row, col - 1),  # left
            (row, col + 1)   # right
        ]

        for next_cell in neighbours:
            r, c = next_cell

            if 0 <= r < rows and 0 <= c < cols:
                if next_cell not in obstacles:  # skip blocked cells
                    new_distance = current_distance + weights[next_cell]

                    if new_distance < distances.get(next_cell, float("inf")):
                        distances[next_cell] = new_distance  # update best cost
                        parent[next_cell] = current  # save previous cell
                        heapq.heappush(priority_queue, (new_distance, next_cell))

    path = []

    if end in parent or start == end:
        current = end

        while current != start:
            path.append(current)
            current = parent[current]

        path.append(start)
        path.reverse()  # start to end order

    return visit_order, path, distances.get(end, None)


def draw_grid(screen, rows, cols, cell_size, start_x, start_y, start, end, obstacles, visited, path, weights):
    for row in range(rows):
        for col in range(cols):
            cell = (row, col)
            x = start_x + col * cell_size
            y = start_y + row * cell_size
            rect = pygame.Rect(x, y, cell_size, cell_size)

            color = WHITE

            if cell in visited:
                color = LIGHT_BLUE  # searched cell

            if cell in path:
                color = YELLOW  # final path

            if cell in obstacles:
                color = DARK  # obstacle

            if cell == start:
                color = GREEN  # start cell

            if cell == end:
                color = RED  # end cell

            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, GREY, rect, 1)

            if cell not in obstacles and cell != start and cell != end:
                draw_text(screen, str(weights[cell]), SMALL_FONT, DARK, x + cell_size // 2, y + cell_size // 2, True)


def get_clicked_cell(mouse_pos, rows, cols, cell_size, start_x, start_y):
    mx, my = mouse_pos

    if mx < start_x or my < start_y:
        return None

    col = (mx - start_x) // cell_size
    row = (my - start_y) // cell_size

    if 0 <= row < rows and 0 <= col < cols:
        return (row, col)  # clicked grid cell

    return None


def run_puzzle_challenges(screen, clock):
    width = screen.get_width()
    center_x = width // 2

    rows = 10
    cols = 15
    cell_size = 42

    grid_width = cols * cell_size
    start_x = center_x - grid_width // 2  # center grid
    start_y = 125

    start = (2, 1)
    end = (7, 13)

    weights = {}

    for row in range(rows):
        for col in range(cols):
            weights[(row, col)] = ((row + col) % 4) + 1  # cost from 1 to 4

    obstacles = {
        (1, 5), (2, 5), (3, 5), (4, 5),
        (6, 3), (6, 4), (6, 5), (6, 6),
        (3, 9), (4, 9), (5, 9), (6, 9),
        (8, 10), (8, 11), (8, 12)
    }

    original_obstacles = set(obstacles)  # used for reset

    visited_order = []
    visited_display = []
    path = []
    path_cost = None
    step_index = 0
    running_path = False
    frame_counter = 0
    speed = 5
    message = "Click cells to add or remove obstacles."

    button_y = 580
    button_gap = 18
    button_widths = [160, 135, 135, 110]
    total_button_width = sum(button_widths) + button_gap * 3
    button_x = center_x - total_button_width // 2  # center buttons

    buttons = {
        "run": Button("Run Dijkstra", button_x, button_y, button_widths[0], 44, LIGHT_BLUE, BLUE),
        "clear": Button("Clear Path", button_x + 178, button_y, button_widths[1], 44, LIGHT_PURPLE, PURPLE),
        "reset": Button("Reset Map", button_x + 331, button_y, button_widths[2], 44, LIGHT_GREEN, GREEN),
        "back": Button("Back", button_x + 484, button_y, button_widths[3], 44, LIGHT_RED, RED)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Puzzle Challenges", TITLE_FONT, DARK, center_x, 50, True)
        draw_text(screen, "Weighted shortest path puzzle using Dijkstra's Algorithm.", NORMAL_FONT, GREY, center_x, 85, True)

        draw_grid(
            screen,
            rows,
            cols,
            cell_size,
            start_x,
            start_y,
            start,
            end,
            obstacles,
            set(visited_display),
            set(path),
            weights
        )

        if running_path:
            frame_counter += 1

            if frame_counter >= speed:
                frame_counter = 0

                if step_index < len(visited_order):
                    visited_display.append(visited_order[step_index])  # show next searched cell
                    step_index += 1
                    message = "Dijkstra is searching for the lowest-cost path."
                else:
                    running_path = False
                    if path:
                        message = f"Lowest-cost path found. Cost: {path_cost}"
                    else:
                        message = "No path found."

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, center_x, 680, True)
        draw_text(
            screen,
            "Numbers = movement cost, green = start, red = end, dark = obstacle, yellow = final path",
            SMALL_FONT,
            GREY,
            center_x,
            720,
            True
        )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                clicked_cell = get_clicked_cell(event.pos, rows, cols, cell_size, start_x, start_y)

                if clicked_cell is not None and not running_path:
                    if clicked_cell != start and clicked_cell != end:
                        if clicked_cell in obstacles:
                            obstacles.remove(clicked_cell)
                            message = "Obstacle removed."
                        else:
                            obstacles.add(clicked_cell)
                            message = "Obstacle added."

                        visited_order = []
                        visited_display = []
                        path = []
                        path_cost = None
                        step_index = 0

            if buttons["run"].is_clicked(event):
                visited_order, path, path_cost = dijkstra_path(rows, cols, start, end, obstacles, weights)
                visited_display = []
                step_index = 0
                running_path = True
                message = "Dijkstra started."

            elif buttons["clear"].is_clicked(event):
                visited_order = []
                visited_display = []
                path = []
                path_cost = None
                step_index = 0
                running_path = False
                message = "Path cleared."

            elif buttons["reset"].is_clicked(event):
                obstacles = set(original_obstacles)
                visited_order = []
                visited_display = []
                path = []
                path_cost = None
                step_index = 0
                running_path = False
                message = "Map reset."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)