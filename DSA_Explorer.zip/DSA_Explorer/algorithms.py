from collections import deque
import heapq


class Stack:
    """Simple stack implementation using LIFO behaviour."""

    def __init__(self):
        """Create an empty stack."""
        self.items = []

    def push(self, value):
        """Add a value to the top of the stack."""
        self.items.append(value)

    def pop(self):
        """Remove and return the top value from the stack."""
        if self.is_empty():
            return None
        return self.items.pop()

    def is_empty(self):
        """Check if the stack is empty."""
        return len(self.items) == 0

    def size(self):
        """Return the number of items in the stack."""
        return len(self.items)


class Queue:
    """Simple queue implementation using FIFO behaviour."""

    def __init__(self):
        """Create an empty queue."""
        self.items = deque()

    def enqueue(self, value):
        """Add a value to the rear of the queue."""
        self.items.append(value)

    def dequeue(self):
        """Remove and return the front value from the queue."""
        if self.is_empty():
            return None
        return self.items.popleft()

    def is_empty(self):
        """Check if the queue is empty."""
        return len(self.items) == 0

    def size(self):
        """Return the number of items in the queue."""
        return len(self.items)


class LinkedList:
    """Simple linked-list-style structure used for visualisation and testing."""

    def __init__(self):
        """Create an empty linked list."""
        self.items = []

    def insert(self, value):
        """Insert a value at the end of the list."""
        self.items.append(value)

    def delete(self):
        """Delete and return the last value from the list."""
        if self.is_empty():
            return None
        return self.items.pop()

    def reverse(self):
        """Reverse the order of the list."""
        self.items.reverse()

    def is_empty(self):
        """Check if the list is empty."""
        return len(self.items) == 0

    def to_list(self):
        """Return the linked list values as a normal Python list."""
        return self.items[:]


class BSTNode:
    """Node used in the Binary Search Tree."""

    def __init__(self, value):
        """Create a tree node with left and right child links."""
        self.value = value
        self.left = None
        self.right = None


def bst_insert(root, value):
    """Insert a value into a Binary Search Tree."""
    if root is None:
        return BSTNode(value)

    if value < root.value:
        root.left = bst_insert(root.left, value)
    elif value > root.value:
        root.right = bst_insert(root.right, value)

    return root


def bst_inorder(root):
    """Return BST values using inorder traversal."""
    result = []

    def visit(node):
        if node is not None:
            visit(node.left)
            result.append(node.value)
            visit(node.right)

    visit(root)
    return result


def bubble_sort(values):
    """Sort a list using Bubble Sort."""
    arr = values[:]

    for i in range(len(arr)):
        for j in range(0, len(arr) - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

    return arr


def selection_sort(values):
    """Sort a list using Selection Sort."""
    arr = values[:]

    for i in range(len(arr)):
        min_index = i

        for j in range(i + 1, len(arr)):
            if arr[j] < arr[min_index]:
                min_index = j

        arr[i], arr[min_index] = arr[min_index], arr[i]

    return arr


def merge_sort(values):
    """Sort a list using Merge Sort."""
    if len(values) <= 1:
        return values[:]

    mid = len(values) // 2
    left = merge_sort(values[:mid])
    right = merge_sort(values[mid:])

    return merge(left, right)


def merge(left, right):
    """Merge two sorted lists into one sorted list."""
    result = []
    i = 0
    j = 0

    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])

    return result


def bfs(graph, start):
    """Perform Breadth-First Search traversal."""
    visited = []
    queue = deque([start])
    seen = set()

    while queue:
        node = queue.popleft()

        if node not in seen:
            seen.add(node)
            visited.append(node)

            for neighbour in graph[node]:
                if neighbour not in seen and neighbour not in queue:
                    queue.append(neighbour)

    return visited


def dfs(graph, start):
    """Perform Depth-First Search traversal."""
    visited = []
    stack = [start]
    seen = set()

    while stack:
        node = stack.pop()

        if node not in seen:
            seen.add(node)
            visited.append(node)

            for neighbour in reversed(graph[node]):
                if neighbour not in seen:
                    stack.append(neighbour)

    return visited


def find_path(rows, cols, start, end, obstacles):
    """Find the shortest path in an unweighted grid using BFS."""
    queue = deque([start])
    visited = {start}
    parent = {}

    while queue:
        current = queue.popleft()

        if current == end:
            break

        row, col = current
        neighbours = [
            (row - 1, col),
            (row + 1, col),
            (row, col - 1),
            (row, col + 1)
        ]

        for next_cell in neighbours:
            r, c = next_cell

            if 0 <= r < rows and 0 <= c < cols:
                if next_cell not in visited and next_cell not in obstacles:
                    visited.add(next_cell)
                    parent[next_cell] = current
                    queue.append(next_cell)

    path = []

    if end in parent or start == end:
        current = end

        while current != start:
            path.append(current)
            current = parent[current]

        path.append(start)
        path.reverse()

    return path

def dijkstra_path(rows, cols, start, end, obstacles, weights):
    """Find the lowest-cost path in a weighted grid using Dijkstra's Algorithm."""
    priority_queue = [(0, start)]
    distances = {start: 0}
    parent = {}
    visit_order = []

    while priority_queue:
        current_distance, current = heapq.heappop(priority_queue)

        if current in visit_order:
            continue

        visit_order.append(current)

        if current == end:
            break

        row, col = current
        neighbours = [
            (row - 1, col),
            (row + 1, col),
            (row, col - 1),
            (row, col + 1)
        ]

        for next_cell in neighbours:
            r, c = next_cell

            if 0 <= r < rows and 0 <= c < cols:
                if next_cell not in obstacles:
                    new_distance = current_distance + weights[next_cell]

                    if new_distance < distances.get(next_cell, float("inf")):
                        distances[next_cell] = new_distance
                        parent[next_cell] = current
                        heapq.heappush(priority_queue, (new_distance, next_cell))

    path = []

    if end in parent or start == end:
        current = end

        while current != start:
            path.append(current)
            current = parent[current]

        path.append(start)
        path.reverse()

    return visit_order, path, distances.get(end, None)