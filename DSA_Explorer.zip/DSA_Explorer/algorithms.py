from collections import deque
import heapq


class Stack:
    """Simple stack implementation using LIFO behaviour."""

    def __init__(self):
        self.items = []  # stack values

    def push(self, value):
        self.items.append(value)  # add to top

    def pop(self):
        if self.is_empty():
            return None
        return self.items.pop()  # remove from top

    def is_empty(self):
        return len(self.items) == 0

    def size(self):
        return len(self.items)


class Queue:
    """Simple queue implementation using FIFO behaviour."""

    def __init__(self):
        self.items = deque()  # queue values

    def enqueue(self, value):
        self.items.append(value)  # add to back

    def dequeue(self):
        if self.is_empty():
            return None
        return self.items.popleft()  # remove from front

    def is_empty(self):
        return len(self.items) == 0

    def size(self):
        return len(self.items)


class LinkedList:
    """Simple linked-list-style structure for testing."""

    def __init__(self):
        self.items = []  # list values

    def insert(self, value):
        self.items.append(value)  # add node

    def delete(self):
        if self.is_empty():
            return None
        return self.items.pop()  # remove last node

    def reverse(self):
        self.items.reverse()  # reverse order

    def is_empty(self):
        return len(self.items) == 0

    def to_list(self):
        return self.items[:]


class BSTNode:
    """Node used in the Binary Search Tree."""

    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def bst_insert(root, value):
    """Insert a value into a Binary Search Tree."""
    if root is None:
        return BSTNode(value)

    if value < root.value:
        root.left = bst_insert(root.left, value)  # smaller goes left
    elif value > root.value:
        root.right = bst_insert(root.right, value)  # bigger goes right

    return root


def bst_inorder(root):
    """Return BST values using inorder traversal."""
    result = []

    def visit(node):
        if node is not None:
            visit(node.left)
            result.append(node.value)  # visit root
            visit(node.right)

    visit(root)
    return result


def bubble_sort(values):
    """Sort a list using Bubble Sort."""
    arr = values[:]

    for i in range(len(arr)):
        for j in range(0, len(arr) - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]  # swap

    return arr


def selection_sort(values):
    """Sort a list using Selection Sort."""
    arr = values[:]

    for i in range(len(arr)):
        min_index = i

        for j in range(i + 1, len(arr)):
            if arr[j] < arr[min_index]:
                min_index = j  # new minimum

        arr[i], arr[min_index] = arr[min_index], arr[i]  # place minimum

    return arr


def merge_sort(values):
    """Sort a list using Merge Sort."""
    if len(values) <= 1:
        return values[:]

    mid = len(values) // 2
    left = merge_sort(values[:mid])  # sort left half
    right = merge_sort(values[mid:])  # sort right half

    return merge(left, right)


def merge(left, right):
    """Merge two sorted lists into one sorted list."""
    result = []
    i = 0
    j = 0

    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])  # remaining left values
    result.extend(right[j:])  # remaining right values

    return result


def bfs(graph, start):
    """Perform Breadth-First Search traversal."""
    visited = []
    queue = deque([start])  # BFS uses queue
    seen = set()

    while queue:
        node = queue.popleft()  # first in first out

        if node not in seen:
            seen.add(node)
            visited.append(node)

            for neighbour in graph[node]:
                if neighbour not in seen and neighbour not in queue:
                    queue.append(neighbour)

    return visited


def dfs(graph, start):
    """Perform Depth-First Search traversal."""
    visited = []
    stack = [start]  # DFS uses stack
    seen = set()

    while stack:
        node = stack.pop()  # last in first out

        if node not in seen:
            seen.add(node)
            visited.append(node)

            for neighbour in reversed(graph[node]):
                if neighbour not in seen:
                    stack.append(neighbour)

    return visited


def find_path(rows, cols, start, end, obstacles):
    """Find the shortest path in an unweighted grid using BFS."""
    queue = deque([start])  # cells to check
    visited = {start}
    parent = {}  # rebuild path

    while queue:
        current = queue.popleft()

        if current == end:
            break

        row, col = current
        neighbours = [
            (row - 1, col),
            (row + 1, col),
            (row, col - 1),
            (row, col + 1)
        ]

        for next_cell in neighbours:
            r, c = next_cell

            if 0 <= r < rows and 0 <= c < cols:
                if next_cell not in visited and next_cell not in obstacles:
                    visited.add(next_cell)
                    parent[next_cell] = current
                    queue.append(next_cell)

    path = []

    if end in parent or start == end:
        current = end

        while current != start:
            path.append(current)
            current = parent[current]

        path.append(start)
        path.reverse()  # start to end

    return path


def dijkstra_path(rows, cols, start, end, obstacles, weights):
    """Find the lowest-cost path in a weighted grid using Dijkstra's Algorithm."""
    priority_queue = [(0, start)]  # lowest cost first
    distances = {start: 0}  # best cost to each cell
    parent = {}  # rebuild path
    visit_order = []  # visited order

    while priority_queue:
        current_distance, current = heapq.heappop(priority_queue)

        if current in visit_order:
            continue

        visit_order.append(current)

        if current == end:
            break

        row, col = current
        neighbours = [
            (row - 1, col),
            (row + 1, col),
            (row, col - 1),
            (row, col + 1)
        ]

        for next_cell in neighbours:
            r, c = next_cell

            if 0 <= r < rows and 0 <= c < cols:
                if next_cell not in obstacles:
                    new_distance = current_distance + weights[next_cell]

                    if new_distance < distances.get(next_cell, float("inf")):
                        distances[next_cell] = new_distance  # update best cost
                        parent[next_cell] = current
                        heapq.heappush(priority_queue, (new_distance, next_cell))

    path = []

    if end in parent or start == end:
        current = end

        while current != start:
            path.append(current)
            current = parent[current]

        path.append(start)
        path.reverse()  # start to end

    return visit_order, path, distances.get(end, None)