import unittest
from algorithms import Stack, Queue, LinkedList, bst_insert, bst_inorder
from algorithms import bubble_sort, selection_sort, merge_sort
from algorithms import bfs, dfs, find_path, dijkstra_path

#automatically check that my algorithms return the correct results

class TestDataStructures(unittest.TestCase):
    def test_stack_push_pop(self):
        stack = Stack()
        stack.push(10)
        stack.push(20)

        self.assertEqual(stack.pop(), 20)
        self.assertEqual(stack.pop(), 10) #This proves the stack follows LIFO because 20 was added last and removed first
        self.assertIsNone(stack.pop())

    def test_queue_enqueue_dequeue(self):
        queue = Queue()
        queue.enqueue(10)
        queue.enqueue(20)

        self.assertEqual(queue.dequeue(), 10)
        self.assertEqual(queue.dequeue(), 20)#This proves the queue follows FIFO because 10 was added first and removed first.
        self.assertIsNone(queue.dequeue())

    def test_linked_list_insert_delete_reverse(self):
        linked_list = LinkedList()
        linked_list.insert(1)
        linked_list.insert(2)
        linked_list.insert(3)

        linked_list.reverse()
        self.assertEqual(linked_list.to_list(), [3, 2, 1]) #This checks that insert, reverse, and delete work correctly.

        self.assertEqual(linked_list.delete(), 1)
        self.assertEqual(linked_list.to_list(), [3, 2])

    def test_bst_inorder(self):
        root = None
        for value in [50, 30, 70, 20, 40, 60, 80]:
            root = bst_insert(root, value)

        self.assertEqual(bst_inorder(root), [20, 30, 40, 50, 60, 70, 80])#This proves the BST inserts values correctly because inorder traversal returns sorted order.


class TestSortingAlgorithms(unittest.TestCase):
    def test_bubble_sort(self):
        values = [5, 2, 9, 1, 3]
        self.assertEqual(bubble_sort(values), [1, 2, 3, 5, 9]) #I tested each sorting algorithm by giving it an unsorted list and checking if the output is sorted correctly.

    def test_selection_sort(self):
        values = [8, 4, 6, 2, 10]
        self.assertEqual(selection_sort(values), [2, 4, 6, 8, 10])

    def test_merge_sort(self):
        values = [7, 3, 5, 1, 9]
        self.assertEqual(merge_sort(values), [1, 3, 5, 7, 9])


class TestGraphAlgorithms(unittest.TestCase):
    def test_bfs(self):
        graph = {
            "A": ["B", "C"],
            "B": ["A", "D", "E"],
            "C": ["A", "F"],
            "D": ["B"],
            "E": ["B", "F"],
            "F": ["C", "E"]
        }

        self.assertEqual(bfs(graph, "A"), ["A", "B", "C", "D", "E", "F"])#This checks that BFS visits nodes level by level.

    def test_dfs(self):
        graph = {
            "A": ["B", "C"],
            "B": ["A", "D", "E"],
            "C": ["A", "F"],
            "D": ["B"],
            "E": ["B", "F"],
            "F": ["C", "E"]
        }

        self.assertEqual(dfs(graph, "A"), ["A", "B", "D", "E", "F", "C"])


class TestPuzzleAlgorithms(unittest.TestCase):
    def test_find_path(self):
        rows = 3
        cols = 3
        start = (0, 0)
        end = (2, 2)
        obstacles = {(1, 1)}

        path = find_path(rows, cols, start, end, obstacles)

        self.assertEqual(path[0], start)
        self.assertEqual(path[-1], end)
        self.assertNotIn((1, 1), path)#This confirms the path avoids obstacles.

    def test_no_path(self):
        rows = 3
        cols = 3
        start = (0, 0)
        end = (2, 2)
        obstacles = {(0, 1), (1, 0)}

        path = find_path(rows, cols, start, end, obstacles)

        self.assertEqual(path, [])

    def test_dijkstra_path(self):
        rows = 3
        cols = 3
        start = (0, 0)
        end = (2, 2)
        obstacles = {(1, 1)}

        weights = {}
        for row in range(rows):
            for col in range(cols):
                weights[(row, col)] = 1

        visit_order, path, cost = dijkstra_path(rows, cols, start, end, obstacles, weights)

        self.assertEqual(path[0], start)
        self.assertEqual(path[-1], end)
        self.assertNotIn((1, 1), path)
        self.assertEqual(cost, 4)#Since every movement cost is 1, the shortest valid path from start to end has total cost 4.
        self.assertIn(end, visit_order)


if __name__ == "__main__":
    unittest.main()



# python3 -m unittest discover tests