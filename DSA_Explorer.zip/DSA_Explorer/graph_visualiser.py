import pygame
import sys
from collections import deque
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 34, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 22, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 18)
SMALL_FONT = pygame.font.SysFont("arial", 14)


def bfs_steps(graph, start):
    visited = set()  # visited nodes
    queue = deque([start])  # BFS uses queue
    steps = []  # animation steps

    while queue:
        node = queue.popleft()  # take first node

        if node not in visited:
            visited.add(node)
            steps.append((node, list(visited), list(queue)))  # save step

            for neighbour in graph[node]:
                if neighbour not in visited and neighbour not in queue:
                    queue.append(neighbour)  # add neighbour to queue
                    steps.append((node, list(visited), list(queue)))

    return steps


def dfs_steps(graph, start):
    visited = set()  # visited nodes
    stack = [start]  # DFS uses stack
    steps = []  # animation steps

    while stack:
        node = stack.pop()  # take last node

        if node not in visited:
            visited.add(node)
            steps.append((node, list(visited), list(stack)))  # save step

            for neighbour in reversed(graph[node]):
                if neighbour not in visited:
                    stack.append(neighbour)  # add neighbour to stack
                    steps.append((node, list(visited), list(stack)))

    return steps


def draw_graph(screen, positions, edges, visited, current_node, selected_node):
    for a, b in edges:
        pygame.draw.line(screen, GREY, positions[a], positions[b], 4)  # draw edge

    for node, pos in positions.items():
        color = LIGHT_BLUE  # normal node

        if node in visited:
            color = LIGHT_GREEN  # visited node

        if node == selected_node:
            color = YELLOW  # start node

        if node == current_node:
            color = ORANGE  # current node

        pygame.draw.circle(screen, color, pos, 34)
        pygame.draw.circle(screen, DARK, pos, 34, 3)
        draw_text(screen, node, SUBTITLE_FONT, DARK, pos[0], pos[1], True)


def get_clicked_node(mouse_pos, positions):
    mx, my = mouse_pos

    for node, pos in positions.items():
        x, y = pos
        distance = ((mx - x) ** 2 + (my - y) ** 2) ** 0.5  # mouse to node distance

        if distance <= 34:
            return node  # clicked node

    return None


def run_graph_visualiser(screen, clock):
    width = screen.get_width()
    center_x = width // 2  # center layout

    graph = {
        "A": ["B", "C"],
        "B": ["A", "D", "E"],
        "C": ["A", "F"],
        "D": ["B"],
        "E": ["B", "F"],
        "F": ["C", "E"]
    }  # adjacency list

    positions = {
        "A": (center_x, 165),
        "B": (center_x - 220, 305),
        "C": (center_x + 220, 305),
        "D": (center_x - 340, 470),
        "E": (center_x - 80, 470),
        "F": (center_x + 190, 470)
    }  # node positions

    edges = [
        ("A", "B"),
        ("A", "C"),
        ("B", "D"),
        ("B", "E"),
        ("C", "F"),
        ("E", "F")
    ]  # graph edges

    selected_node = "A"
    current_node = None
    visited = []
    steps = []
    step_index = 0
    running_algorithm = False
    frame_counter = 0
    speed = 35  # animation speed
    current_algorithm = "None"
    message = "Click a node to choose the start node."

    button_y = 610
    button_width = 135
    button_gap = 18
    total_width = button_width * 4 + button_gap * 3
    start_x = center_x - total_width // 2  # center buttons

    buttons = {
        "bfs": Button("Run BFS", start_x, button_y, button_width, 44, LIGHT_BLUE, BLUE),
        "dfs": Button("Run DFS", start_x + button_width + button_gap, button_y, button_width, 44, LIGHT_GREEN, GREEN),
        "reset": Button("Reset", start_x + (button_width + button_gap) * 2, button_y, button_width, 44, LIGHT_PURPLE, PURPLE),
        "back": Button("Back", start_x + (button_width + button_gap) * 3, button_y, button_width, 44, LIGHT_RED, RED)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Graph Visualiser", TITLE_FONT, DARK, center_x, 50, True)
        draw_text(screen, "BFS and DFS traversal on an undirected graph.", NORMAL_FONT, GREY, center_x, 85, True)
        draw_text(screen, f"Start Node: {selected_node}    Algorithm: {current_algorithm}", SUBTITLE_FONT, DARK, center_x, 125, True)

        draw_graph(screen, positions, edges, visited, current_node, selected_node)

        if running_algorithm and steps:
            frame_counter += 1

            if frame_counter >= speed:
                frame_counter = 0

                if step_index < len(steps):
                    current_node, visited, storage = steps[step_index]  # next saved step
                    step_index += 1
                    message = f"Visiting node {current_node}"
                else:
                    running_algorithm = False
                    message = f"{current_algorithm} traversal complete."

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, center_x, 700, True)
        draw_text(screen, "Green = visited, orange = current, yellow = start node", SMALL_FONT, GREY, center_x, 730, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                clicked_node = get_clicked_node(event.pos, positions)

                if clicked_node is not None and not running_algorithm:
                    selected_node = clicked_node  # new start node
                    current_node = None
                    visited = []
                    steps = []
                    step_index = 0
                    current_algorithm = "None"
                    message = f"Start node selected: {selected_node}"

            if buttons["bfs"].is_clicked(event):
                steps = bfs_steps(graph, selected_node)  # make BFS steps
                step_index = 0
                visited = []
                current_node = None
                running_algorithm = True
                current_algorithm = "BFS"
                message = "BFS traversal started."

            elif buttons["dfs"].is_clicked(event):
                steps = dfs_steps(graph, selected_node)  # make DFS steps
                step_index = 0
                visited = []
                current_node = None
                running_algorithm = True
                current_algorithm = "DFS"
                message = "DFS traversal started."

            elif buttons["reset"].is_clicked(event):
                current_node = None
                visited = []
                steps = []
                step_index = 0
                running_algorithm = False
                current_algorithm = "None"
                message = "Graph reset."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)