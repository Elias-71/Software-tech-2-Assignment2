import pygame
import sys
from collections import deque
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 32, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 22, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 18)
SMALL_FONT = pygame.font.SysFont("arial", 14)


def bfs_steps(graph, start):
    visited = set()
    queue = deque([start])
    steps = []

    while queue:
        node = queue.popleft()

        if node not in visited:
            visited.add(node)
            steps.append((node, list(visited), list(queue)))

            for neighbour in graph[node]:
                if neighbour not in visited and neighbour not in queue:
                    queue.append(neighbour)
                    steps.append((node, list(visited), list(queue)))

    return steps


def dfs_steps(graph, start):
    visited = set()
    stack = [start]
    steps = []

    while stack:
        node = stack.pop()

        if node not in visited:
            visited.add(node)
            steps.append((node, list(visited), list(stack)))

            for neighbour in reversed(graph[node]):
                if neighbour not in visited:
                    stack.append(neighbour)
                    steps.append((node, list(visited), list(stack)))

    return steps


def draw_graph(screen, positions, edges, visited, current_node, selected_node):
    for a, b in edges:
        pygame.draw.line(screen, GREY, positions[a], positions[b], 4)

    for node, pos in positions.items():
        color = LIGHT_BLUE

        if node in visited:
            color = LIGHT_GREEN

        if node == selected_node:
            color = YELLOW

        if node == current_node:
            color = ORANGE

        pygame.draw.circle(screen, color, pos, 32)
        pygame.draw.circle(screen, DARK, pos, 32, 3)
        draw_text(screen, node, SUBTITLE_FONT, DARK, pos[0], pos[1], True)


def get_clicked_node(mouse_pos, positions):
    mx, my = mouse_pos

    for node, pos in positions.items():
        x, y = pos
        distance = ((mx - x) ** 2 + (my - y) ** 2) ** 0.5

        if distance <= 32:
            return node

    return None


def run_graph_visualiser(screen, clock):
    graph = {
        "A": ["B", "C"],
        "B": ["A", "D", "E"],
        "C": ["A", "F"],
        "D": ["B"],
        "E": ["B", "F"],
        "F": ["C", "E"]
    }

    positions = {
        "A": (500, 150),
        "B": (300, 280),
        "C": (700, 280),
        "D": (200, 430),
        "E": (430, 430),
        "F": (650, 430)
    }

    edges = [
        ("A", "B"),
        ("A", "C"),
        ("B", "D"),
        ("B", "E"),
        ("C", "F"),
        ("E", "F")
    ]

    selected_node = "A"
    current_node = None
    visited = []
    steps = []
    step_index = 0
    running_algorithm = False
    frame_counter = 0
    speed = 35
    current_algorithm = "None"
    message = "Click a node to choose the start node."

    buttons = {
        "bfs": Button("Run BFS", 160, 570, 130, 42, LIGHT_BLUE, BLUE),
        "dfs": Button("Run DFS", 310, 570, 130, 42, LIGHT_GREEN, GREEN),
        "reset": Button("Reset", 460, 570, 130, 42, LIGHT_PURPLE, PURPLE),
        "back": Button("Back", 610, 570, 130, 42, LIGHT_RED, RED)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Graph Visualiser", TITLE_FONT, DARK, 500, 45, True)
        draw_text(screen, "BFS and DFS traversal on an undirected graph.", NORMAL_FONT, GREY, 500, 78, True)
        draw_text(screen, f"Start Node: {selected_node}    Algorithm: {current_algorithm}", SUBTITLE_FONT, DARK, 500, 110, True)

        draw_graph(screen, positions, edges, visited, current_node, selected_node)

        if running_algorithm and steps:
            frame_counter += 1

            if frame_counter >= speed:
                frame_counter = 0

                if step_index < len(steps):
                    current_node, visited, storage = steps[step_index]
                    step_index += 1
                    message = f"Visiting node {current_node}"
                else:
                    running_algorithm = False
                    message = f"{current_algorithm} traversal complete."

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, 500, 645, True)
        draw_text(screen, "Green = visited, orange = current, yellow = start node", SMALL_FONT, GREY, 500, 675, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                clicked_node = get_clicked_node(event.pos, positions)

                if clicked_node is not None and not running_algorithm:
                    selected_node = clicked_node
                    current_node = None
                    visited = []
                    steps = []
                    step_index = 0
                    current_algorithm = "None"
                    message = f"Start node selected: {selected_node}"

            if buttons["bfs"].is_clicked(event):
                steps = bfs_steps(graph, selected_node)
                step_index = 0
                visited = []
                current_node = None
                running_algorithm = True
                current_algorithm = "BFS"
                message = "BFS traversal started."

            elif buttons["dfs"].is_clicked(event):
                steps = dfs_steps(graph, selected_node)
                step_index = 0
                visited = []
                current_node = None
                running_algorithm = True
                current_algorithm = "DFS"
                message = "DFS traversal started."

            elif buttons["reset"].is_clicked(event):
                current_node = None
                visited = []
                steps = []
                step_index = 0
                running_algorithm = False
                current_algorithm = "None"
                message = "Graph reset."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)