import pygame
import random
import sys
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 32, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 22, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 18)
SMALL_FONT = pygame.font.SysFont("arial", 14)


def bubble_sort_steps(values):
    arr = values[:]
    steps = []

    for i in range(len(arr)):
        for j in range(0, len(arr) - i - 1):
            steps.append((arr[:], j, j + 1, "compare"))
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                steps.append((arr[:], j, j + 1, "swap"))

    steps.append((arr[:], -1, -1, "done"))
    return steps


def selection_sort_steps(values):
    arr = values[:]
    steps = []

    for i in range(len(arr)):
        min_index = i
        steps.append((arr[:], i, min_index, "select"))

        for j in range(i + 1, len(arr)):
            steps.append((arr[:], min_index, j, "compare"))
            if arr[j] < arr[min_index]:
                min_index = j
                steps.append((arr[:], i, min_index, "new_min"))

        if min_index != i:
            arr[i], arr[min_index] = arr[min_index], arr[i]
            steps.append((arr[:], i, min_index, "swap"))

    steps.append((arr[:], -1, -1, "done"))
    return steps


def merge_sort_steps(values):
    arr = values[:]
    steps = []

    def merge_sort(left, right):
        if right - left <= 1:
            return

        mid = (left + right) // 2
        merge_sort(left, mid)
        merge_sort(mid, right)

        temp = []
        i = left
        j = mid

        while i < mid and j < right:
            steps.append((arr[:], i, j, "compare"))
            if arr[i] <= arr[j]:
                temp.append(arr[i])
                i += 1
            else:
                temp.append(arr[j])
                j += 1

        while i < mid:
            temp.append(arr[i])
            i += 1

        while j < right:
            temp.append(arr[j])
            j += 1

        for index, value in enumerate(temp):
            arr[left + index] = value
            steps.append((arr[:], left + index, -1, "merge"))

    merge_sort(0, len(arr))
    steps.append((arr[:], -1, -1, "done"))
    return steps


def draw_bars(screen, values, index_a, index_b, action):
    max_value = max(values)
    bar_width = 42
    gap = 12
    start_x = 120
    base_y = 500
    max_height = 300

    for i, value in enumerate(values):
        height = int((value / max_value) * max_height)
        x = start_x + i * (bar_width + gap)
        y = base_y - height

        color = LIGHT_BLUE

        if action == "done":
            color = LIGHT_GREEN
        elif i == index_a or i == index_b:
            if action == "compare":
                color = YELLOW
            elif action == "swap":
                color = LIGHT_RED
            elif action == "select":
                color = ORANGE
            elif action == "new_min":
                color = LIGHT_PURPLE
            elif action == "merge":
                color = LIGHT_GREEN

        rect = pygame.Rect(x, y, bar_width, height)
        pygame.draw.rect(screen, color, rect, border_radius=6)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=6)

        draw_text(screen, str(value), SMALL_FONT, DARK, x + bar_width // 2, base_y + 20, True)


def run_sorting_visualiser(screen, clock):
    values = random.sample(range(10, 100), 10)
    steps = []
    step_index = 0
    sorting = False
    speed = 12
    frame_counter = 0
    current_algorithm = "None"
    message = "Choose a sorting algorithm."

    buttons = {
        "bubble": Button("Bubble Sort", 60, 570, 140, 42, LIGHT_BLUE, BLUE),
        "selection": Button("Selection Sort", 215, 570, 155, 42, LIGHT_BLUE, BLUE),
        "merge": Button("Merge Sort", 385, 570, 135, 42, LIGHT_BLUE, BLUE),
        "reset": Button("New Values", 535, 570, 135, 42, LIGHT_GREEN, GREEN),
        "pause": Button("Pause/Run", 685, 570, 130, 42, LIGHT_PURPLE, PURPLE),
        "back": Button("Back", 835, 570, 110, 42, LIGHT_RED, RED)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Sorting Visualiser", TITLE_FONT, DARK, 500, 45, True)
        draw_text(screen, "Compare how sorting algorithms organise data step by step.", NORMAL_FONT, GREY, 500, 78, True)
        draw_text(screen, f"Algorithm: {current_algorithm}", SUBTITLE_FONT, DARK, 500, 120, True)

        if steps and step_index < len(steps):
            current_values, index_a, index_b, action = steps[step_index]
        else:
            current_values, index_a, index_b, action = values, -1, -1, "idle"

        draw_bars(screen, current_values, index_a, index_b, action)

        if sorting and steps:
            frame_counter += 1
            if frame_counter >= speed:
                frame_counter = 0
                if step_index < len(steps) - 1:
                    step_index += 1
                else:
                    sorting = False
                    values = steps[-1][0]
                    message = "Sorting complete."

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, 500, 645, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and steps:
                    sorting = not sorting
                    message = "Animation running." if sorting else "Animation paused."

                elif event.key == pygame.K_r:
                    values = random.sample(range(10, 100), 10)
                    steps = []
                    step_index = 0
                    sorting = False
                    current_algorithm = "None"
                    message = "New values generated."

            if buttons["bubble"].is_clicked(event):
                steps = bubble_sort_steps(values)
                step_index = 0
                sorting = True
                current_algorithm = "Bubble Sort"
                message = "Bubble Sort is running."

            elif buttons["selection"].is_clicked(event):
                steps = selection_sort_steps(values)
                step_index = 0
                sorting = True
                current_algorithm = "Selection Sort"
                message = "Selection Sort is running."

            elif buttons["merge"].is_clicked(event):
                steps = merge_sort_steps(values)
                step_index = 0
                sorting = True
                current_algorithm = "Merge Sort"
                message = "Merge Sort is running."

            elif buttons["reset"].is_clicked(event):
                values = random.sample(range(10, 100), 10)
                steps = []
                step_index = 0
                sorting = False
                current_algorithm = "None"
                message = "New values generated."

            elif buttons["pause"].is_clicked(event):
                if steps:
                    sorting = not sorting
                    message = "Animation running." if sorting else "Animation paused."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)