import pygame
import random
import sys
from ui import Button, draw_text

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
GREEN = (40, 170, 100)
LIGHT_GREEN = (210, 245, 225)
RED = (220, 70, 70)
LIGHT_RED = (255, 215, 215)
PURPLE = (140, 90, 220)
LIGHT_PURPLE = (230, 220, 255)
GREY = (120, 130, 150)
YELLOW = (255, 230, 140)
ORANGE = (255, 185, 90)

TITLE_FONT = pygame.font.SysFont("arial", 34, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 22, bold=True)
NORMAL_FONT = pygame.font.SysFont("arial", 18)
SMALL_FONT = pygame.font.SysFont("arial", 14)


def bubble_sort_steps(values):
    arr = values[:]
    steps = []  # store animation steps

    for i in range(len(arr)):
        for j in range(0, len(arr) - i - 1):
            steps.append((arr[:], j, j + 1, "compare"))
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]  # swap values
                steps.append((arr[:], j, j + 1, "swap"))

    steps.append((arr[:], -1, -1, "done"))
    return steps


def selection_sort_steps(values):
    arr = values[:]
    steps = []  # store animation steps

    for i in range(len(arr)):
        min_index = i
        steps.append((arr[:], i, min_index, "select"))

        for j in range(i + 1, len(arr)):
            steps.append((arr[:], min_index, j, "compare"))
            if arr[j] < arr[min_index]:
                min_index = j
                steps.append((arr[:], i, min_index, "new_min"))

        if min_index != i:
            arr[i], arr[min_index] = arr[min_index], arr[i]  # swap minimum
            steps.append((arr[:], i, min_index, "swap"))

    steps.append((arr[:], -1, -1, "done"))
    return steps


def merge_sort_steps(values):
    arr = values[:]
    steps = []  # store animation steps

    def merge_sort(left, right):
        if right - left <= 1:
            return

        mid = (left + right) // 2
        merge_sort(left, mid)
        merge_sort(mid, right)

        temp = []
        i = left
        j = mid

        while i < mid and j < right:
            steps.append((arr[:], i, j, "compare"))
            if arr[i] <= arr[j]:
                temp.append(arr[i])
                i += 1
            else:
                temp.append(arr[j])
                j += 1

        while i < mid:
            temp.append(arr[i])
            i += 1

        while j < right:
            temp.append(arr[j])
            j += 1

        for index, value in enumerate(temp):
            arr[left + index] = value  # merge value back
            steps.append((arr[:], left + index, -1, "merge"))

    merge_sort(0, len(arr))
    steps.append((arr[:], -1, -1, "done"))
    return steps


def draw_bars(screen, values, index_a, index_b, action, center_x):
    max_value = max(values)
    bar_width = 48
    gap = 14
    total_width = len(values) * bar_width + (len(values) - 1) * gap
    start_x = center_x - total_width // 2  # center bars
    base_y = 535
    max_height = 330

    for i, value in enumerate(values):
        height = int((value / max_value) * max_height)
        x = start_x + i * (bar_width + gap)
        y = base_y - height

        color = LIGHT_BLUE

        if action == "done":
            color = LIGHT_GREEN
        elif i == index_a or i == index_b:
            if action == "compare":
                color = YELLOW
            elif action == "swap":
                color = LIGHT_RED
            elif action == "select":
                color = ORANGE
            elif action == "new_min":
                color = LIGHT_PURPLE
            elif action == "merge":
                color = LIGHT_GREEN

        rect = pygame.Rect(x, y, bar_width, height)
        pygame.draw.rect(screen, color, rect, border_radius=6)
        pygame.draw.rect(screen, DARK, rect, 2, border_radius=6)

        draw_text(screen, str(value), SMALL_FONT, DARK, x + bar_width // 2, base_y + 22, True)


def run_sorting_visualiser(screen, clock):
    width = screen.get_width()
    height = screen.get_height()
    center_x = width // 2

    values = random.sample(range(10, 100), 10)  # random values
    steps = []
    step_index = 0
    sorting = False
    speed = 12
    frame_counter = 0
    current_algorithm = "None"
    message = "Choose a sorting algorithm."

    button_y = 635
    button_gap = 15
    button_widths = [145, 165, 140, 140, 135, 110]
    total_button_width = sum(button_widths) + button_gap * (len(button_widths) - 1)
    start_button_x = center_x - total_button_width // 2  # center buttons

    buttons = {
        "bubble": Button("Bubble Sort", start_button_x, button_y, button_widths[0], 44, LIGHT_BLUE, BLUE),
        "selection": Button("Selection Sort", start_button_x + 160, button_y, button_widths[1], 44, LIGHT_BLUE, BLUE),
        "merge": Button("Merge Sort", start_button_x + 340, button_y, button_widths[2], 44, LIGHT_BLUE, BLUE),
        "reset": Button("New Values", start_button_x + 495, button_y, button_widths[3], 44, LIGHT_GREEN, GREEN),
        "pause": Button("Pause/Run", start_button_x + 650, button_y, button_widths[4], 44, LIGHT_PURPLE, PURPLE),
        "back": Button("Back", start_button_x + 800, button_y, button_widths[5], 44, LIGHT_RED, RED)
    }

    running = True

    while running:
        screen.fill(WHITE)

        draw_text(screen, "Sorting Visualiser", TITLE_FONT, DARK, center_x, 50, True)
        draw_text(screen, "Compare how sorting algorithms organise data step by step.", NORMAL_FONT, GREY, center_x, 85, True)
        draw_text(screen, f"Algorithm: {current_algorithm}", SUBTITLE_FONT, DARK, center_x, 130, True)

        if steps and step_index < len(steps):
            current_values, index_a, index_b, action = steps[step_index]
        else:
            current_values, index_a, index_b, action = values, -1, -1, "idle"

        draw_bars(screen, current_values, index_a, index_b, action, center_x)

        if sorting and steps:
            frame_counter += 1
            if frame_counter >= speed:
                frame_counter = 0
                if step_index < len(steps) - 1:
                    step_index += 1  # next animation step
                else:
                    sorting = False
                    values = steps[-1][0]
                    message = "Sorting complete."

        for button in buttons.values():
            button.draw(screen)

        draw_text(screen, message, NORMAL_FONT, DARK, center_x, 710, True)
        draw_text(screen, "Keyboard: Space = pause/resume, R = new values", SMALL_FONT, GREY, center_x, 740, True)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and steps:
                    sorting = not sorting  # pause or resume
                    message = "Animation running." if sorting else "Animation paused."

                elif event.key == pygame.K_r:
                    values = random.sample(range(10, 100), 10)
                    steps = []
                    step_index = 0
                    sorting = False
                    current_algorithm = "None"
                    message = "New values generated."

            if buttons["bubble"].is_clicked(event):
                steps = bubble_sort_steps(values)
                step_index = 0
                sorting = True
                current_algorithm = "Bubble Sort"
                message = "Bubble Sort is running."

            elif buttons["selection"].is_clicked(event):
                steps = selection_sort_steps(values)
                step_index = 0
                sorting = True
                current_algorithm = "Selection Sort"
                message = "Selection Sort is running."

            elif buttons["merge"].is_clicked(event):
                steps = merge_sort_steps(values)
                step_index = 0
                sorting = True
                current_algorithm = "Merge Sort"
                message = "Merge Sort is running."

            elif buttons["reset"].is_clicked(event):
                values = random.sample(range(10, 100), 10)
                steps = []
                step_index = 0
                sorting = False
                current_algorithm = "None"
                message = "New values generated."

            elif buttons["pause"].is_clicked(event):
                if steps:
                    sorting = not sorting  # pause or resume
                    message = "Animation running." if sorting else "Animation paused."

            elif buttons["back"].is_clicked(event):
                running = False

        pygame.display.flip()
        clock.tick(60)