import random
import timeit
from algorithms import bubble_sort, selection_sort, merge_sort, bfs, dfs, find_path


def benchmark_sorting():
    print("Sorting Algorithm Benchmark")
    print("-" * 60)
    print(f"{'Algorithm':<18}{'Input Size':<15}{'Average Time (ms)':<20}")
    print("-" * 60)

    sizes = [50, 100, 200, 400]

    for size in sizes:
        data = list(range(size, 0, -1))

        algorithms = [
            ("Bubble Sort", bubble_sort),
            ("Selection Sort", selection_sort),
            ("Merge Sort", merge_sort)
        ]

        for name, function in algorithms:
            total_time = timeit.timeit(lambda: function(data), number=5)
            average_time = (total_time / 5) * 1000
            print(f"{name:<18}{size:<15}{average_time:<20.4f}")

    print()


def benchmark_graphs():
    print("Graph Traversal Benchmark")
    print("-" * 60)
    print(f"{'Algorithm':<18}{'Nodes':<15}{'Average Time (ms)':<20}")
    print("-" * 60)

    sizes = [50, 100, 200, 400]

    for size in sizes:
        graph = {}

        for i in range(size):
            neighbours = []
            if i + 1 < size:
                neighbours.append(i + 1)
            if i + 2 < size:
                neighbours.append(i + 2)
            graph[i] = neighbours

        algorithms = [
            ("BFS", bfs),
            ("DFS", dfs)
        ]

        for name, function in algorithms:
            total_time = timeit.timeit(lambda: function(graph, 0), number=10)
            average_time = (total_time / 10) * 1000
            print(f"{name:<18}{size:<15}{average_time:<20.4f}")

    print()


def benchmark_pathfinding():
    print("Pathfinding Benchmark")
    print("-" * 60)
    print(f"{'Grid Size':<18}{'Average Time (ms)':<20}")
    print("-" * 60)

    sizes = [10, 20, 30, 40]

    for size in sizes:
        rows = size
        cols = size
        start = (0, 0)
        end = (rows - 1, cols - 1)

        obstacles = set()
        random.seed(1)

        for _ in range(size):
            obstacle = (random.randint(0, rows - 1), random.randint(0, cols - 1))
            if obstacle != start and obstacle != end:
                obstacles.add(obstacle)

        total_time = timeit.timeit(lambda: find_path(rows, cols, start, end, obstacles), number=10)
        average_time = (total_time / 10) * 1000
        print(f"{str(size) + 'x' + str(size):<18}{average_time:<20.4f}")

    print()


def main():
    benchmark_sorting()
    benchmark_graphs()
    benchmark_pathfinding()


if __name__ == "__main__":
    main()