import pygame
import sys
from ui import Button, draw_text
from data_structures import run_data_structures_module
from sorting_visualiser import run_sorting_visualiser
from graph_visualiser import run_graph_visualiser
from puzzles import run_puzzle_challenges

pygame.init()

WIDTH = 1000
HEIGHT = 700
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer and Visualiser App")
CLOCK = pygame.time.Clock()

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
RED = (220, 70, 70)
GREY = (120, 130, 150)

TITLE_FONT = pygame.font.SysFont("arial", 42, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 24)
SMALL_FONT = pygame.font.SysFont("arial", 18)


def draw_main_menu(buttons):
    SCREEN.fill(WHITE)

    draw_text(SCREEN, "DSA Explorer and Visualiser App", TITLE_FONT, DARK, WIDTH // 2, 80, True)
    draw_text(SCREEN, "Software Technology 2 Project", SUBTITLE_FONT, GREY, WIDTH // 2, 125, True)
    draw_text(SCREEN, "Choose a module to explore data structures and algorithms visually.", SMALL_FONT, GREY, WIDTH // 2, 160, True)

    for button in buttons:
        button.draw(SCREEN)

    draw_text(SCREEN, "Select a module to begin", SMALL_FONT, GREY, WIDTH // 2, 650, True)

    pygame.display.flip()


def placeholder_screen(title, description):
    back_button = Button("Back to Menu", 360, 560, 280, 60, LIGHT_BLUE, BLUE)
    running = True

    while running:
        SCREEN.fill(WHITE)

        draw_text(SCREEN, title, TITLE_FONT, DARK, WIDTH // 2, 110, True)
        draw_text(SCREEN, description, SUBTITLE_FONT, GREY, WIDTH // 2, 180, True)
        draw_text(SCREEN, "Module screen", SMALL_FONT, GREY, WIDTH // 2, 240, True)
        back_button.draw(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if back_button.is_clicked(event):
                running = False

        pygame.display.flip()
        CLOCK.tick(60)


def main():
    buttons = [
        Button("Data Structures", 350, 220, 300, 60, LIGHT_BLUE, BLUE),
        Button("Sorting Visualiser", 350, 300, 300, 60, LIGHT_BLUE, BLUE),
        Button("Graph Visualiser", 350, 380, 300, 60, LIGHT_BLUE, BLUE),
        Button("Puzzle Challenges", 350, 460, 300, 60, LIGHT_BLUE, BLUE),
        Button("Exit", 350, 540, 300, 60, (255, 210, 210), RED)
    ]

    running = True

    while running:
        draw_main_menu(buttons)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if buttons[0].is_clicked(event):
                run_data_structures_module(SCREEN, CLOCK)

            elif buttons[1].is_clicked(event):
                run_sorting_visualiser(SCREEN, CLOCK)

            elif buttons[2].is_clicked(event):
                run_graph_visualiser(SCREEN, CLOCK)

            elif buttons[3].is_clicked(event):
                run_puzzle_challenges(SCREEN, CLOCK)

            elif buttons[4].is_clicked(event):
                running = False

        CLOCK.tick(60)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()