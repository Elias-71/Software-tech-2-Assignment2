import pygame
import sys
from ui import Button, draw_text
from data_structures import run_data_structures_module
from sorting_visualiser import run_sorting_visualiser
from graph_visualiser import run_graph_visualiser
from puzzles import run_puzzle_challenges

pygame.init()  # Start pygame

WIDTH = 1200
HEIGHT = 800
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))  # Create window
pygame.display.set_caption("DSA Explorer and Visualiser App")
CLOCK = pygame.time.Clock()  # Control FPS

WHITE = (245, 247, 250)
DARK = (25, 30, 45)
BLUE = (52, 112, 255)
LIGHT_BLUE = (210, 225, 255)
RED = (220, 70, 70)
GREY = (120, 130, 150)

TITLE_FONT = pygame.font.SysFont("arial", 44, bold=True)
SUBTITLE_FONT = pygame.font.SysFont("arial", 25)
SMALL_FONT = pygame.font.SysFont("arial", 18)


def draw_main_menu(buttons):
    SCREEN.fill(WHITE)  # Background color

    draw_text(SCREEN, "DSA Explorer and Visualiser App", TITLE_FONT, DARK, WIDTH // 2, 90, True)
    draw_text(SCREEN, "Software Technology 2 Project", SUBTITLE_FONT, GREY, WIDTH // 2, 140, True)
    draw_text(SCREEN, "Choose a module to explore data structures and algorithms visually.", SMALL_FONT, GREY, WIDTH // 2, 180, True)

    for button in buttons:
        button.draw(SCREEN)  # Draw all buttons

    draw_text(SCREEN, "Select a module to begin", SMALL_FONT, GREY, WIDTH // 2, 735, True)

    pygame.display.flip()  # Update screen


def placeholder_screen(title, description):
    back_button = Button("Back to Menu", WIDTH // 2 - 160, 650, 320, 65, LIGHT_BLUE, BLUE)
    running = True

    while running:
        SCREEN.fill(WHITE)

        draw_text(SCREEN, title, TITLE_FONT, DARK, WIDTH // 2, 120, True)
        draw_text(SCREEN, description, SUBTITLE_FONT, GREY, WIDTH // 2, 190, True)
        draw_text(SCREEN, "Module screen", SMALL_FONT, GREY, WIDTH // 2, 250, True)

        back_button.draw(SCREEN)

        for event in pygame.event.get():  # Check events
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if back_button.is_clicked(event):  # Back button
                running = False

        pygame.display.flip()
        CLOCK.tick(60)  # 60 FPS


def main():
    button_width = 380
    button_height = 65
    button_x = WIDTH // 2 - button_width // 2  # Center buttons

    buttons = [
        Button("Data Structures", button_x, 250, button_width, button_height, LIGHT_BLUE, BLUE),
        Button("Sorting Visualiser", button_x, 335, button_width, button_height, LIGHT_BLUE, BLUE),
        Button("Graph Visualiser", button_x, 420, button_width, button_height, LIGHT_BLUE, BLUE),
        Button("Puzzle Challenges", button_x, 505, button_width, button_height, LIGHT_BLUE, BLUE),
        Button("Exit", button_x, 590, button_width, button_height, (255, 210, 210), RED)
    ]

    running = True

    while running:
        draw_main_menu(buttons)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if buttons[0].is_clicked(event):
                run_data_structures_module(SCREEN, CLOCK)

            elif buttons[1].is_clicked(event):
                run_sorting_visualiser(SCREEN, CLOCK)

            elif buttons[2].is_clicked(event):
                run_graph_visualiser(SCREEN, CLOCK)

            elif buttons[3].is_clicked(event):
                run_puzzle_challenges(SCREEN, CLOCK)

            elif buttons[4].is_clicked(event):  
                running = False

        CLOCK.tick(60)

    pygame.quit()  # Close 
    sys.exit()


if __name__ == "__main__":
    main()  # Run app